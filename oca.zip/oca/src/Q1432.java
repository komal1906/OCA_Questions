import java.io.IOException;

public class Q1432 {
	public void main(String fileName)throws IOException
	{
		
	}

}
