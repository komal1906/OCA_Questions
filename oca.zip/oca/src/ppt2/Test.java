package ppt2;
import pp1.Acct;

public class Test extends Acct {
	public static void main(String[] args)
	{
		Acct obj=new Test();
		//obj.p;
		obj.r;
		obj.s;
		System.out.println();
	}

}
