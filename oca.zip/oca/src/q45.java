
public class q45 {

}
