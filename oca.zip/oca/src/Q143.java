
public class Q143 {
	public void a()
	{
		int a;
	}

}

