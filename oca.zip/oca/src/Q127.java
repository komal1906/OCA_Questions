
// class Q127 {
	
public class A
{
	int a=4;
	int b=5;
}
class Q127
{
	public static void main(String[] args)
	{
		A a=new A();
		System.out.println(a.a);
	}
}