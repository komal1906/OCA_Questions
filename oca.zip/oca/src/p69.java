class Person
{
	
}
class Father extends Person
{
	public void dance()throws ClassCastException
	{
		
	}
}

/*import java.time.LocalDate;
import java.util.*;
class Person{
	
}
class Emp extends Person{
	
}*/
/*class Course
{
	static int enrollments;
}*/
class p69
{
	public static void main(String[] args)
	{
		Person p=new Person();
		try {
			((Father)p).dance();
		}
		/*catch(NullPointerException e)
		{
			
		}
		catch(ClassCastException e){}
	     catch(Exception e) {}
		catch(Throwable t) {}*/
		
		catch(ClassCastException e){}
		catch(NullPointerException e)
		{
			
		}
	     catch(Exception e) {}
		catch(Throwable t) {}
		
		
		
	}
}	/*
		 * String n1[][]=new String[1][2]; String n2[][]=new String[][] {{},{}}; String
		 * n3[][]=new String[2][2]; String n4[][]=new String[][] {{null},new String[]
		 * {"a","b"},{new String()}}; String n5[][]=new String[][2]; String n6[][]=new
		 * String[][]{"A","B"}; String n7[][]=new String[][]{{"A"},{"B"}}; String
		 * n8[][]=new String[] {{"A"},{"B"}};
		 */
		/*int a=10;int b=20;boolean c=false;
		if(b>a)if(++a==10)if(c!=true)System.out.println(1);
		else System.out.println(2);else System.out.println(3);
	op=3
	}
	
	
	
	
}*/
		/*ArrayList<Object>list=new ArrayList<>();
		list.add(new String("123"));
		list.add(new Person());
		list.add(new Emp());
		list.add(new String[] {"abcd","xyz"});
		list.add(LocalDate.now().plus(1));
	}
 }
		*/
	/*	Course c1=new Course();
		Course c2=new Course();
		c1.enrollments=100;
		c2.enrollments=200;
		System.out.println(c1.enrollments+c2.enrollments);
	}
}
		*/
		
		
		

		