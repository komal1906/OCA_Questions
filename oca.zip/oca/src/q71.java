
public class q71 {
	public static void main(String[] args)
	{
		String[][] chs=new String[2][];
		chs[0]=new String[2];
		chs[1]=new String[5];
		
	}

}
