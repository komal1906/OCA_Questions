
public  abstract class Q24 {
	public abstract int calculatePrice(Q24 t);
	public void printQ24(Q24 t)
	{
		
	}
	public final void printsQ24(Q24 t1)
	{
		
	}
	

}
