
public abstract class P74 {
	public abstract int calculatePrice(P74 p);
	public void printP74(P74)
	{
		
	}
}