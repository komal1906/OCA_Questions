
public class q74 {
	public static void main(String[] args)
	{
		String names[] = {"thomas","peter","joseph"};
		String pws[]= new String[3];
		int idx=0;
		try {
			for(String n:names)
			{
				pws [idx]= n.substring(2,6);
				idx++;
			}
			
		}
		catch(Exception e) {
			System.out.println("invad name");
		}
		for(String p:pws)
		{
			System.out.println(p);
		}
	}

}
