
public class Q119 {
	public static void main(String[] args)
	{
		int wd=0;
		String days[]= {"sun","mon","wed","sat"};
		for(String s:days)
		{
			switch(s)
			{
			case "sat":
			case "sun":
				wd-=1; // wd= wd-1  -1
				break;
			case "mon":
				wd++;  //0
				
			case "wed":
				wd +=2;// 2 //4
				
			}
		}
		System.out.println(wd);
	}

}
