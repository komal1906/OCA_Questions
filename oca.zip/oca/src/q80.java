
public class q80 {
String name;
int age;
public q80(String name)
{
	this();
	setName(name);
}
public q80(String name,int age)
{
	q80(name);
	setAge(age);
}

}
