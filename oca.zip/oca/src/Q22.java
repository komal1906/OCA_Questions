import java.time.LocalDate;

public class Q22 {
	public static void main(String[] args)
	{
		LocalDate date=LocalDate.of(2012, 01, 32);
		date.plus(10);
		System.out.println(date);
		
	}

}
