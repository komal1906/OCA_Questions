import java.util.ArrayList;

public class q83 {
public static void main(String[] args)
{
	int i=0;
	ArrayList myList=new ArrayList();
	String[] myArray;
	try
	{
		while(i<5)
		{
			myList.add("myString");
			i++;
			
		}
	}
	catch(RuntimeException re)
	{
		System.out.println("caugght a runtimeexception");
	}
	catch(Exception e)
	{
		System.out.println("caught an exception");
	}
	System.out.println("ready to use");
}

}
