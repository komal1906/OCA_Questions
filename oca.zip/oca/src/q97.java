

class CD{
	int r;
	CD(int r)
	{
		this.r=r;
	}
}
 class q971 extends CD {
	 int c;

	q971(int r,int c) {
		super(r);
		this.c=c;
		// TODO Auto-generated constructor stub
	}

}
 public class q97{
	 public static void main(String[] args)
	 {
		 q971 dvd=new q971(10,20);
		 System.out.println(dvd);
	 }
 }
