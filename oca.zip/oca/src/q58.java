
public class q58 {
	public static void main(String args[])
	{
		float var1=(12_345.01>=123_45.00)?12_456:124_56.02f;
		float var2=var1+1024;
		System.out.println(var2);
		
	}
	
}
