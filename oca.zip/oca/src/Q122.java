
 class Q122a {
	String type="Canine";
	int maxSpeed=60;
	Q122a()
	{
		
	}
	Q122a(String type,int maxSpeed)
	{
		this.type=type;
		this.maxSpeed=maxSpeed;
	}
	}
class Q1221 extends Q122a
{
	String bounds;
	Q1221(String bounds)
	{
		super();
		this.bounds=bounds;
	}
	
	Q1221(String type,int maxSpeed,String bounds)
	{
		super( type, maxSpeed);
		this.bounds=bounds;
    }
}
public class Q122
{
	public static void main(String[] args)
	{
		Q1221 wolf=new Q1221("long");
		Q1221 tiger=new Q1221("feline",80,"short");
		System.out.println(wolf.type+" "+wolf.maxSpeed+" "+wolf.bounds);
		System.out.println(tiger.type+" "+tiger.maxSpeed+" "+tiger.bounds);

	}
}

