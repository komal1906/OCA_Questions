
public class Toy {

}
