
abstract class Q136 {
	int price;
	public static void insertToy()
	{
		
	}
	public int calculatePrice()
	{
		return price;
		
	}
	public abstract int computeDiscount();

}
