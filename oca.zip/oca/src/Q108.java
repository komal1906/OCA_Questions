
public class Q108 {
	public static void main(String[] args)
	
	{
		int ivar=100;
		float fvar=100.00f;
		double dvar=13;
		ivar=fvar;
		fvar=ivar;
		dvar=fvar;
		fvar=dvar;
		dvar=ivar;
		ivar=dvar;
		
	}

}
