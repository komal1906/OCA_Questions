
public class q60 {
	public static void main(String[] args)
	{
		int[] intArr= {15,23,6,6,8};
		intArr[2]=intArr[4];
		intArr[4]=90;
		System.out.println(intArr);
	}

}
