
public class q36 {
	public static void main(String[] args)
	{
		StringBuilder sb1=new StringBuilder("duke");
		//Object sb1 = null;
		String str1=sb1.toString();
		//String str2=str1;
		//String str2=new String(str1);
		//String str2=sb1.toString();
		String str2="duke";
		System.out.println(str1==str2);
		
	}

}
