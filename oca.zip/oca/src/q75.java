
public class q75 {

	public static void main(String[] args) {
		int num=5;
		do {
			System.out.println(num--+" ");
		}while(num==0);
		// TODO Auto-generated method stub

	}

}
