
public class Q115 {
	String myStr="7007";
	public void doStuff(String str)
	{
		int myNum=0;
		try {
			String myStr=str;
			myNum=Integer.parseInt(myStr);
		}
		catch(NumberFormatException ne)
		{
			System.out.println("error");
		}
		System.out.println("myStr: "+myStr+" myNum:"+myNum);
	}
	public static void main(String[] args)
	{
		Q115 ob=new Q115();
		ob.doStuff("9009");
	}
	

}
