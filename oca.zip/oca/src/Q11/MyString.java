package Q11;

public class MyString {
	String msg;
	MyString(String msg)

	{
		this.msg=msg;
	}
}
