package Q11;

public class Test {
	public static void main(String[] args)
	{
		//MyString mystr=new MyString("hii");
		System.out.println("hello"+new StringBuilder("java se 8"));
		System.out.println("hello"+new MyString("java se 8"));

	}

}
