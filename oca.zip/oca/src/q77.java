
public class q77 {

//	private static final String TRUE = null;

	public static void main(String[] args) {
		boolean a=new Boolean(Boolean.valueOf("TRUE"));
		boolean b=new Boolean(null);
		System.out.println(a+" "+b);
		
		// TODO Auto-generated method stub

	}

}
