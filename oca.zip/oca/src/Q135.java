
public class Q135 {
	public static void main(String[] args)
	{
		//boolean opt=true;
		String opt="true";
		switch(opt)
		
		{
		
		
		case "true": System.out.println("true");
		break;
		
		default:
			System.out.println("***");
		}
		System.out.println("done");
		}

}
