
public class Q137 {
	void readCard(int cardNo)throws Exception
	{
		System.out.println("Reading Card");
	}
	void checkCard(int cardNo)throws RuntimeException
	{
		System.out.println("Checking Card");
	}
	public static void main(String[] args)
	{
		Q137 ex=new Q137();
		int cardNo=134;
		ex.checkCard(cardNo);
		ex.readCard(cardNo);
	}

}
