
// abstract class q52 
 //{
	// private static int i;
	 //public void doStuff()
	 //{
		 
	// }
	 //public q52() {
 //}
 //}
//final class q52{
	//public q52()
	//{
		
	//}
//}
//public class q52
//{
	//private static int i;
	//private q52() {
//}
//}

public class q52
{
	int a1;
	public static void doProduct(int a)
	{
		a=a*a;
	}
	public static void doString(StringBuilder s)
	{
		s.append(" "+s);
	}
	public static void main(String[] args)
	{
		q52 ite=new q52();
		ite.a1=11;
		StringBuilder sb=new StringBuilder("hello");
		Integer i=10;
		doProduct(i);
		doString(sb);
		doProduct(ite.a1);
		System.out.println(i+""+sb+ite.a1);
		
	}
}
	 

