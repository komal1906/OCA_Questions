
 interface Read {
	 public void readBook();
	 public void setBookMark();
	 

}
abstract class Book implements Read{
	public void readBook()
	{
		
	}
}
abstract class EBook extends Book
{
	public void readBook()
	{
		
	}

	
	
}