
public class Person {
	String name;
	int age;
	

	public Person(String n,int a) {
		name=n;
		age=a;
		// TODO Auto-generated constructor stub
	}


	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}


	/**
	 * @param name the name to set
	 */
	

	/**
	 * @return the age
	 */
	public int getAge() {
		return age;
	}

}
