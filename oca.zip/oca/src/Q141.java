
public class Q141 {
	String name;
	boolean contract;
	double salary;
	Q141()
	{
		//this.name=new String("joe");
		//this.contract=new Boolean(true);
		//this.salary=new Double(100);
	//name="joe";
	//contract=TRUE;
	this("joe",true,100);
	
	
	
	
	}
	
	
	public String toString()
	{
		return name+":"+contract+":"+salary;
		
	}
	public static void main(String[] args)
	{
		Q141 e= new Q141();
		//e.name="joe";
		//e.contract=true;
		//e.salary=100;
		//this.name= new String("joe");
		//this.contract=true;
		//this.salary=100;
		
		
		
		System.out.println(e);
		
	}

}
