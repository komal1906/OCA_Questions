
public class q81 {

	int count;
	public static void displayMsg()
	{
		count++;
		System.out.println("welcome"+"visit count"+count);
	}
	public static void main(String[] args)
	{
		q81.displayMsg();
		
		q81.displayMsg();
	}

}
