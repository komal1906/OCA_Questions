package oca;

public class Q5 {

}
