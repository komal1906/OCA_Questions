package oca;

public class Q106 {
	char c;
	boolean b;
	float f;
	int i;
	void printAll()
	{
		System.out.println("c="+c);
		System.out.println("b="+b);
		System.out.println("f="+f);
		System.out.println("i="+i);
	}
	public static void main(String[] args)
	{
		Q106 q=new Q106();
		q.printAll();
	}

}
