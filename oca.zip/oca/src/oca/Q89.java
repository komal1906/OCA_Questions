package oca;

import java.util.ArrayList;
import java.util.List;

class P
{
	String name;
	public P(String name)
	{
		this.name=name;
	}
}

public class Q89 {
	public static void main(String[] args)
	{
		List ps=new ArrayList();
		P p1=new P("MIKE");
		ps.add(p1);
		
		int f=ps.indexOf(p1);
		if(f>=0)
		{
			System.out.println("Mike Found");
		}
		
	}

}
