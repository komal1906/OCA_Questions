package oca;

public class Q92 {
	public static void main(String[] args)
	{
		String names[]=("Thomas","Peter","Joseph");
		
		
	}

}
