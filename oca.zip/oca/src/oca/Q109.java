package oca;

public class Q109 {

	public static void main(String[] args) {
		String myStr="Hello World";
		myStr.trim();
		int i1=myStr.indexOf(" ");
		int i2=myStr.indexOf("");
		System.out.println(i1);
		// TODO Auto-generated method stub

	}

}
