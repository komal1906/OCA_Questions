package oca;

public class Loops {

		public static void main(String[] args) {  
		    //using for loop  
		   /* for(int i=1;i<=10;i++)
		    {  
		        if(i==5){  
		            //breaking the loop  
		            break;  
		        } 
		        //break;
		        System.out.println(i);  
		    }  
		}  */
		
			
	// TODO Auto-generated constructor stub
			  //outer loop   
		/*
		 * for(int i=1;i<=3;i++){ //inner loop for(int j=1;j<=3;j++) { if(i==2&&j==2){
		 * //using break statement inside the inner loop break; }
		 * System.out.println(i+" "+j); } }
		 */
 
		int i=1;  
	    while(i<=10)
	    {  
	        if(i==5){  
	            //using break statement  
	            i++;  
	            break;//it will break the loop  
	        }  
	        System.out.println(i);  
	        i++;  
	    }  
		
		
		  int j=1;  
		    //do-while loop  
		    do{  
		        if(j==5){  
		           //using break statement  
		           j++;  
		           break;//it will break the loop  
		        }  
		        System.out.println(j);  
		        j++;  
		    }while(j<=10);  
		}  
		 
}

		


