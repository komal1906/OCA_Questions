package oca;

public class Q88 {
	public static void main(String[] args)
	{
		String stuff="tv";
		String res=null;
		
		//res=stuff.equals("tv")?"walter":stuff.contentEquals("movie")?"white":"no result";
		//System.out.println(res);
		stuff.equals("tv")?res="walter":stuff.equals("movie")?res="white":res="no result";
	}

}
