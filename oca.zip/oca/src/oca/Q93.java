package oca;
class Employee
{
	private String name;
	private int age;
	private int salary;
	
	public Employee(String name,int age)
	{
		setName(name);
		setAge(age);
		setSalary(2000);
	}
	
	public Employee(String name,int age,int salary)
	{
		setSalary(salary);
		this(name,age);
	}
	public void printDetails() {
		System.out.println(name+":"+age+":"+salary);
	}
	
}

public class Q93 {
	public static void main(String[] args)
	{
		Employee e1=new Employee();
		Employee e2=new Employee("jack",50);
		Employee e3=new Employee("chloe",40,5000);
		e1.printDetails();
		e2.printDetails();
		e3.printDetails();
	}

}
