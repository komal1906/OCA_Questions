package oca;

public class Q102 {
	 static int count=0;
	int i=0;
	
	public void changeCount()
	{
		while(i<5)
		{
			i++;
			count++;
		}
	}
	public static void main(String[] args)
	{
		 Q102 c1=new  Q102();
		 Q102 c2=new  Q102();
		 c1.changeCount();
		c2.changeCount();
		 System.out.println(c1.count+":"+c2.count);
		 
	}

}
