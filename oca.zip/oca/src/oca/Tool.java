package oca;

public class Tool implements Exportable{
	

	@Override
	protected void export() {
		// TODO Auto-generated method stub
		
	}

}
