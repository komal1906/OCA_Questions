package oca;

public class Q1081 {

	public static void main(String[] args) {
		int[] stack = { 10, 20, 30 };
		int size = 3;
		int idx = 0;

		// TODO Auto-generated method stub

		//do {
		//	idx++;
		//} while (idx < size - 1);

		
		  while(idx<=size-1) { idx++; }
		 

		System.out.println("top element is" + stack[idx]);

	}

}
