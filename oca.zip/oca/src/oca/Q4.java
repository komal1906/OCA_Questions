 package oca;

 class Q41 {
	public void displayQ4()
	{
		System.out.println("c2");
	}

}
 interface I
 {
	 public void displayI();
 }
 class Qq4 extends Q41 implements I
 {
	 public void displayI()
	 {
		 System.out.println("c1");
	 }
 }
 public class Q4{
	 public static void main(String[] args)
	 {
		 Q41 obj1=new Qq4();
		 I obj2=new Qq4();
		 
		 Q41 s=obj2;
		 I t= obj1;
		 t.displayI();
		 
		 s.displayQ41();
	 }
 }

