package oca;

public class Q112 {

	public static void main(String[] args) {
  int data[]= {2010,2013,2014,2015,2014};
  int key=2014;
  int count=0;
  for(int e:data)
  {
	  if(e!=key)
	  {
		 // continue:
			  continue;
			  // count++;
	  }
	  count++;
  }
  System.out.println(count+"found");
		// TODO Auto-generated method stub

	}

}
