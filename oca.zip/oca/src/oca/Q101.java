package oca;

public class Q101 {
	String name;
	int age;
	
	/*
	 * public Q101() {
	 * 
	 * }
	 */
	
	public Q101(String name)
	{
		this();
		setName(name);
		
	}
	public Q101(String name,int age)
	{
		Q101(name);
		setAge(age);
		//this.name=name;
		//this.age=age;
	}
	public String show()
	{
		return name+" "+age;
	}
	public static void main(String[] args)
	{
		Q101 q1=new Q101("jessie");
		Q101 q2=new Q101("WALTER",52);
		System.out.println(q1.show());
		System.out.println(q2.show());
	}

}
