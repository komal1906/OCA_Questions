package oca;

public class Q75 {
	
	int id;
	String name;
	public Q75(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
	public static void main(String[] args)
	{
		Q75 q1=new Q75(101,"pen");
		Q75 q2=new Q75(101,"pen");
		Q75 q3=q1;
		boolean ans1=q1==q2;
		boolean ans2=q1.name.equals(q2.name);
		System.out.println(ans1+":"+ans2);
		
	}
}
