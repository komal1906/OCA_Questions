package oca;

public class Q80 {
	public static void main(String[] args)
	{
		int ans=0;
		try {
			int num=10;
			int div=0;
			ans=num/div;
		}catch(ArithmeticException ae)
		{
			//ans=0;
		}catch(Exception e)
		{
			System.out.println("invalid calculation");
		}
		System.out.println("answer="+ans);
	}

}
