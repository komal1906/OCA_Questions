package oca;

public class Q100 {
	 static int count;
	
	public static void displayMsg()
	{
		count++;
		System.out.println("welcome"+"visit count :"+count);
	}
	public static void main(String[] args)
	{
		 Q100.displayMsg();
		 Q100.displayMsg();
		
	}

}
