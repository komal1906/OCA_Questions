package oca;

public class Q72 {
	String myStr="7007";
	
	public void doStuff(String str)
	{
		int myNum=0;
		try {
			String myStr=str;
			myNum=Integer.parseInt(myStr);
		}
		catch(NumberFormatException ne)
		{
			System.out.println("error");
		}
		System.out.println("mystr:"+myStr +"  myNum:"+myNum);
	}
	public static void main(String[] args)
	{
		 Q72 ob=new Q72();
		 ob.doStuff("9009");
	}

}
