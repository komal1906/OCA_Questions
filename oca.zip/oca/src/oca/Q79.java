package oca;

class Caller{
	private void init()
	{
		System.out.println("initialized");
	}
	private void start()
	{
		init();
		System.out.println("started");
	}
}

    public class Q79
    {
    	public static void main(String[] args)
    	{
    		//Caller c-new Caller();
    		Caller c=new Caller();
    		c.start();
    		c.init();
    	}

}
