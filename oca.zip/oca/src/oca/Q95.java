package oca;
class A1
{
	public void test() {
		System.out.println("A");
	}
}
class B extends A1
{
	public void test() {
		System.out.println("B");
	}
}
public class Q95 extends A1 {
	public void test() {
		System.out.println("C");
	}
	public static void main(String[] args)
	{
		A1 b1=new A1();
		A1 b2=new Q95();
		b1=(A1)b2;
		A1 b3=(B)b2;
		b1.test();
		b3.test();
		
	}

}
