package oca;

public class Q81 {
	int x;
	int y;
	public void doStuff(int x,int y)
	{
		this.x=x;
		//y=this.y;
		this.y=y;
	}
	public void display()
	{
		System.out.println(x+""+y+":");
	}
	public static void main(String[] args)
	{
		Q81 q1=new Q81();
		q1.x=100;
		q1.y=200;
		Q81 q2=new Q81();
		q2.doStuff(q1.x, q1.y);
		q1.display();
		q2.display();
	}

}
