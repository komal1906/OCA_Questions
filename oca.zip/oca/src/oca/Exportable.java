package oca;

public interface Exportable {
	void export();

}
