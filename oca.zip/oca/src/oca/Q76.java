package oca;

public class Q76 {
	public int salary;
	
}

class Manager1 extends Q76{
	public int budget;
}
 class Director extends Manager1
{
	public int stockOptions;

public static void main(String[] args)
{
	Q76 q76=new Q76();
	Manager1 mgr=new Manager1();
	Director director=new Director();
	q76.salary=50_000;
	director.salary=10_000;
	director.budget=20_000;
	mgr.budget=1_000_000;//static
	director.stockOptions=500;
	director.stockOptions=1_000;
	
}
}