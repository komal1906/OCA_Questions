package oca;

 class CheckingAccount
{
	public int amount;
	
	public CheckingAccount()
	{
		//amount=100;
		this.amount=100;
	}
}
public class Q115 {
	public static void main(String[] args)
	{
		CheckingAccount acct=new CheckingAccount();
		acct.amount=100;
		//this.amount=100;
		//amount=100;
		System.out.println("amount");
	}
	
}
