package P2;
import P1.Acc;

public class Test extends Acc {
	public static void main(String[] args)
	{
		Acc obj=new Test();
		//obj.p;
		obj.r;
		obj.s;
		obj.p;
		obj.q;
		
	}

}
