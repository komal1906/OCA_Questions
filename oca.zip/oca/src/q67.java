
public class q67 {
	public String name;
	public int moons;
	
	public q67(String name,int moons)
	{
		this.name=name;
		this.moons=moons;
	}


public static void main(String args[])
{
	q67[] q= 
		{ new q67("mercury",0),new q67("venus",0),new q67("earth",1),new q67("mars",2)
};
	System.out.println(q);
	System.out.println(q[2]);

	System.out.println(q[2].moons);

	
}
}