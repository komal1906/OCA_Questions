package Q1.R;

//import Q1.AA;
import Q1.*;

public class RR {
	public void doStuff()
	{
		AA a=new AA();
		
	}

}
