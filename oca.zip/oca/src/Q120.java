import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Q120 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] arr= {"hi","hello"};
		List<String> arrlist=new ArrayList<>(Arrays.asList(arr));
		if(arrlist.removeIf((String s)->(s.length()<=2))) {
			System.out.println(s+"removed");
		}

	}

}
