
public class q82 {

	public static void main(String[] args)
	{
		String stuff="tv";
		String res=null;
		res=stuff.equals("tv")?"walter":stuff.equals("movie")?"white":"no result";
		System.out.println(res);
	}

}
