interface Exportable
{
	void export();
}
class Tool implements Exportable
{
	protected void export()
	{
		System.out.println("tool:export");
	}
	
}
class ReportTool implements Exportable
{
	public void export()
	{
		System.out.println("Rtool:export");
	}
	
}

public class q53 {

}
