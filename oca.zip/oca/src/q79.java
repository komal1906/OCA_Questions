
public class q79 {
public static void main(String[] args)
{
	q79 ts=new q79();
	System.out.println(isAvailable+" ");
	isAvailable=ts.doStuff();
	System.out.println(isAvailable);
	
}
public static boolean doStuff()
{
	return !isAvailable;
}
static boolean isAvailable=false;

}
