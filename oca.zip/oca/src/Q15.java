interface Downloadable
{
	public void download();
}
interface Readable extends Downloadable{
	public void readBook();
	
}
abstract class Book implements Readable
{
	public void readBook() {
		System.out.println("Read Book");
	}
}
class EBook extends Book{
	public void readBook() {
		System.out.println("read e-book");
		
	}

	//@Override
	//public void download() {
		// TODO Auto-generated method stub
		
	//}
}

	//@Override
	//public void download() {
		// TODO Auto-generated method stub
		
	//}

public class Q15 {
	public static void main(String[] args)
	{
		Book book1=new EBook();
		book1.readBook();
	}

}
