
public class Q16 {
	static int x;
	static int y;
	
	public Q16(int x,int y)
	{
		initialize(x,y);
	}

	public void initialize(int x2, int y2) {
		this.x=x*x;
		this.y=y*y;
		System.out.println(x+" "+y);
		// TODO Auto-generated method stub
		
	}
	public static void main(String[] args)
	{
		int  x=3,y=5;
		//Q16 obj=new Q16(x,y);
		Q16 obj=new Q16(x,y);
		System.out.println(x+" "+y);
		
	}

}
