package p111;

import java.io.IOException;

public class Q14311 {
	public void main(String fileName)throws IOException
	{
		
	}



}
