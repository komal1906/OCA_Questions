class Base{
	public void test()
}
public class Q23 {

}
