package P1;

public class Acc {
	public int p;
	protected int q;
	protected int r;
	public int s;

}
