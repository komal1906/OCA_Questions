
public class q86 {

	public static int stVar=100;
	public int var=200;
	public String toString()
	{
		return var+":"+stVar;
	}
public static void main(String[] args)
{
	q86 t1=new q86();
	t1.var=300;
	System.out.println(t1);
	q86 t2=new q86();
	t2.stVar=300;
	System.out.println(t2);
}
}
