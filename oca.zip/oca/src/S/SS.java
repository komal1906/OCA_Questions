package S;

//import Q1.AA;
//import Q1.R.RR;
import Q1.*;
import Q1.R.*;

public class SS {
	public static void main(String[] args)
	{
		AA o1=new AA();
		RR o2=new RR();
	//	System.out.println();
	}

}
