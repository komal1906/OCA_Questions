
public class q87 {
	public static void main(String[] args)
	{
		//Byte x=1;
		//short x=1;
		//String x="1";
		//Long x=1;
		//Double x=1;
		Integer x=new Integer("1");
		
		switch(x)
		{
		case 1:System.out.println("one");
		break;
		
		case 2:System.out.println("two");
		break;
		}
	}
}
