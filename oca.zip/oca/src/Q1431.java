
public class Q1431 {
	private int doStuff()
	{
		private int x=100;
		return x++;
	}

}
