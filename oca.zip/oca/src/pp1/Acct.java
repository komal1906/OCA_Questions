package pp1;

public class Acct {
	int p;
	private int q;
	protected int r;
	public int s;

}
